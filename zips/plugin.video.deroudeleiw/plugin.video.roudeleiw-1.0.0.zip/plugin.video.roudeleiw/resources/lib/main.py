import sys
from urllib.parse import parse_qs
import xbmc
import xbmcplugin
import xbmcgui

import movies
import series
import eum

# --- Kodi handles ---
handle = int(sys.argv[1])
base_url = sys.argv[0]

# Share handles
movies.handle = handle
movies.base_url = base_url
series.handle = handle
series.base_url = base_url

# --- Parse query ---
args = parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
action = args.get('action', [None])[0]

# --- DEBUG LOGGING ---
xbmc.log(f"[ROUDELEIW] main.py START | action={action} | args={args}", xbmc.LOGINFO)

# --- Main menu ---
def list_categories():
    items = [
        ("Filmer", "search_movies"),
        ("Serien", "search_series"),
        ('EUM','search_eum')
    ]

    for title, action_name in items:
        url = f"{base_url}?action={action_name}"
        li = xbmcgui.ListItem(title)
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

# --- Router ---
action = args.get("action", [None])[0]

try:
    if not action:
        # Root of addon
        list_categories()

    elif action in (
        "search_movies",
        "list_movie_providers"
    ):
        movies.router(handle,action, args,base_url)

    elif action in (
        "list_series",
        "search_series",
        "list_seasons",
        "list_episodes",
        "list_providers"
    ):
        series.router(handle,action, args,base_url)
    elif action in (
        "search_eum",
        "open_eum"
    ):
        eum.router(handle,action, args,base_url)
    else:
        xbmc.log(f"[ROUDELEIW] Unknown action: {action}", xbmc.LOGWARNING)
        list_categories()

except Exception as e:
    xbmc.log(f"Unhandled exception in main.py: {e}", xbmc.LOGERROR)
    xbmcplugin.endOfDirectory(handle)


