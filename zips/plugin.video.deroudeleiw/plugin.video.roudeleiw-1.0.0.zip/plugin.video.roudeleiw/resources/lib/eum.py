import requests
from bs4 import BeautifulSoup
import xbmc
import xbmcplugin
import xbmcgui
from urllib.parse import urlencode, quote_plus, urlparse, quote
import sys
from helper import prompt_user_input
import re
import urllib.request
from html.parser import HTMLParser

base_url = None

BASE_URL = "https://www.effedupmovies.com/"
SERVER = "http://neckelpi.ddns.net:8001"
#SERVER = "http://127.0.0.1:8001"

# --- URL builder ---
def build_url(params):
   return BASE_URL + "?" + urlencode(params, quote_via=quote_plus)
def build_plugin_url(params):
    from urllib.parse import urlencode
    return f"plugin://plugin.video.roudeleiw/?{urlencode(params, quote_via=quote_plus)}"

def log(msg):
    xbmc.log(f"[ROUDELEIW] {msg}", xbmc.LOGINFO)   


# --- Router ---
def router(handle, action, args, base_url):
    """
    Main router for all series-related actions
    """
    log(f"action={action} | args={args}")

    # Map actions to functions
    routes = {
        "search_eum": prompt_eum_search,
        "open_eum": open_eum
      #  "list_seasons": series2.action_list_seasons,
       # "list_episodes": series2.action_list_episodes,
       #"list_movie_providers": list_movie_providers
    }

    func = routes.get(action)
    if not func:
        log(f"Unknown action: {action}")
        xbmcplugin.endOfDirectory(handle)
        return

    try:
        if action in ("search_eum"):
            term = args.get("term", [""])[0]
            func(handle)  # pass term, handle, base_url

        elif action == "open_eum":
            movie_url = args.get("movie_url", [""])[0]
            title = args.get("title", [""])[0]
            if movie_url:
                func(handle, movie_url, title)        
            else:
                log("play_movie called without movie_url")
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())

    except Exception as e:
        log(f"Exception in action '{action}': {e}")
        import traceback
        log(traceback.format_exc())
        xbmcplugin.endOfDirectory(handle)



# --- UI ---
def prompt_eum_search(handle):
    # Get search term from reusable helper
    term = prompt_user_input("Enter EUM movie", handle)
    if not term:
        return

    # Call your existing list_series function
    list_eums(handle,term)

def list_eums(handle,term):
    if not term:
        xbmcplugin.endOfDirectory(handle)
        return

    xbmc.log(f"[ROUDELEIW] list_eums | Searching for: {term}", xbmc.LOGINFO)

    movies = search_eums(term)
    items_found = 0

    for movie in movies:

        title = movie.get("title", "")
        image = movie.get("image", "")
        url = movie.get("url", "")

        # Create list item
        li = xbmcgui.ListItem(label=title)

        # Set metadata
        li.setInfo(
            "video",
            {
                "title": title,
                "plot": "",
                "mediatype": "movie"
            }
        )

        # Set artwork if available
        if image:
            li.setArt({
                "thumb": image,
                "poster": image,
                "fanart": image
            })

        # Since this is NOT directly playable yet
        li.setProperty("IsPlayable", "true")

        # Build plugin URL
        item_url = build_plugin_url({
            "action": "open_eum",
            "movie_url": url,
            "title": title
        })

        # Add item to Kodi directory
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=item_url,
            listitem=li,
            isFolder=False   # TRUE if it opens another page
        )

        items_found += 1
        xbmc.log(f"[ROUDELEIW] Added: {title}", xbmc.LOGINFO)

    xbmcplugin.endOfDirectory(handle)

    xbmc.log(f"[ROUDELEIW] Total items added: {items_found}", xbmc.LOGINFO)


def build_search_url(query):
    """Build the paginated search URL for a given query string."""
    encoded = query.replace(" ", "+")
    log(f"{BASE_URL}/?s={encoded}")
    return f"{BASE_URL}/?s={encoded}"


import requests
from urllib.parse import urljoin

def search_eums(term):
    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    response = requests.get(build_search_url(term), headers=headers, timeout=10)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")

    movies = []

    # adjust these selectors to match the site structure
    container = soup.select_one("div.posts-layout")

    if container:
    # find all anchor tags that contain images
        anchors = container.select("article a:has(img)")

        for a in anchors:
            title = a.get("title")
            url = a.get("href")

            img = a.find("img")
            image = img.get("src") if img else None

            if title and url:
                movies.append({
                    "title": title.strip(),
                    "url": url.strip(),
                    "image": image.strip() if image else None
            })

    for movie in movies:
        log(movie)

    return movies


def open_eum( handle,movie_url, title):
    log("OPEN_EUM CALLED")
    src = extract_video_src(movie_url)
    proxy_link=get_proxy_link_from_server(src);
    #proxy_link="http://127.0.0.1:8001/proxy/32b11579-9bc8-4ca9-9a00-230e30b89f06"


    if not proxy_link:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=proxy_link)
    li.setInfo("video", {"title": title})

    xbmcplugin.setResolvedUrl(handle, True, li)

def extract_video_src(movie_url):
    headers = {
        "User-Agent": "Mozilla/5.0",
        "Referer": "https://www.effedupmovies.com/"
    }

    response = requests.get(movie_url, headers=headers, timeout=10)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")

    video = soup.find("video")

    if not video:
        log("No video tag found")
        return None

    # direct src on <video>
    src = video.get("src")

    # OR inside <source>
    if not src:
        source = video.find("source")
        if source:
            src = source.get("src")

    log(f"Video SRC found: {src}")
    return src

def get_proxy_link_from_server(url):
    """Ask local server to extract proxy URL from hoster page."""
    try:
        r = requests.get(f"{SERVER}/extract1", params={"url": url}, timeout=60)
        r.raise_for_status()
        data = r.json()
        log(f"SERVER RESPONSE | Episode URL: {data}")
        return data.get("proxy_url")
    except requests.RequestException as e:
        log(f"Server request failed: {e}")
        return None