import requests
from bs4 import BeautifulSoup
import xbmc
import xbmcplugin
import xbmcgui
from urllib.parse import urlencode, quote_plus, urlparse, quote
import sys
from helper import prompt_user_input
import re
import urllib.request
from html.parser import HTMLParser

handle = None
base_url = None


HEADERS = {"User-Agent": "Mozilla/5.0", "Referer": "https://filmpalast.to"} #test out without referer
SERVER = "http://neckelpi.ddns.net:8000"


# --- URL builder ---
def build_url(params):
   return base_url + "?" + urlencode(params, quote_via=quote_plus)

def log(msg):
    xbmc.log(f"[ROUDELEIW] {msg}", xbmc.LOGINFO)   

# --- Router ---
def router(handle, action, args, base_url):
    """
    Main router for all series-related actions
    """
    log(f"action={action} | args={args}")

    # Map actions to functions
    routes = {
        "search_movies": prompt_movies_search,
      #  "list_seasons": series2.action_list_seasons,
       # "list_episodes": series2.action_list_episodes,
       "list_movie_providers": list_movie_providers
    }

    func = routes.get(action)
    if not func:
        log(f"Unknown action: {action}")
        xbmcplugin.endOfDirectory(handle)
        return

    try:
        if action in ("search_movies"):
            term = args.get("term", [""])[0]
            func(handle)  # pass term, handle, base_url

        elif action == "list_movie_providers":
            movie_url = args.get("movie_url", [""])[0]
            title = args.get("title", [""])[0]
            if movie_url:
                func( movie_url, title)        
            else:
                log("play_movie called without movie_url")
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())

    except Exception as e:
        log(f"Exception in action '{action}': {e}")
        import traceback
        log(traceback.format_exc())
        xbmcplugin.endOfDirectory(handle)


# --- UI ---
def prompt_movies_search(handle):
    # Get search term from reusable helper
    term = prompt_user_input("Enter movie name", handle)
    if not term:
        return

    # Call your existing list_series function
    list_movies(handle,term)



def list_movies(handle,term):
    if not term:
        xbmcplugin.endOfDirectory(handle)
        return

    xbmc.log(f"[ROUDELEIW] list_movies | Searching for: {term}", xbmc.LOGINFO)

    movies = search_movies(term)
    items_found = 0

    for movie in movies:

        title = movie.get("title", "")
        image = movie.get("image", "")
        url = movie.get("url", "")

        # Create list item
        li = xbmcgui.ListItem(label=title)

        # Set metadata
        li.setInfo(
            "video",
            {
                "title": title,
                "plot": "",
                "mediatype": "movie"
            }
        )

        # Set artwork if available
        if image:
            li.setArt({
                "thumb": image,
                "poster": image,
                "fanart": image
            })

        # Since this is NOT directly playable yet
        li.setProperty("IsPlayable", "true")

        # Build plugin URL
        item_url = build_url({
            "action": "list_movie_providers",
            "movie_url": url,
            "title": title
        })

        # Add item to Kodi directory
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=item_url,
            listitem=li,
            isFolder=False   # TRUE if it opens another page
        )

        items_found += 1
        xbmc.log(f"[ROUDELEIW] Added: {title}", xbmc.LOGINFO)

    xbmcplugin.endOfDirectory(handle)

    xbmc.log(f"[ROUDELEIW] Total items added: {items_found}", xbmc.LOGINFO)












BASE_URL = "https://filmpalast.to"


class MovieParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.movies = []
        self.in_article = False
        self.in_h2 = False
        self.current_title = ""
        self.current_url = ""
        self.current_image = ""
        self.total_pages = 1

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "article" and "liste" in attrs.get("class", ""):
            self.in_article = True
            self.current_title = ""
            self.current_url = ""
            self.current_image = ""
        if self.in_article and tag == "h2":
            self.in_h2 = True
        if self.in_h2 and tag == "a" and "href" in attrs:
            self.current_url = attrs["href"]
            self.current_title = attrs.get("title", "")
        if self.in_article and tag == "img" and "cover-opacity" in attrs.get("class", ""):
            src = attrs.get("src", "")
            if src:
                self.current_image = src if src.startswith("http") else BASE_URL + src
        if tag == "a" and "pageing" in attrs.get("class", ""):
            href = attrs.get("href", "")
            match = re.search(r'/(\d+)$', href)
            if match:
                page_num = int(match.group(1))
                if page_num > self.total_pages:
                    self.total_pages = page_num

    def handle_endtag(self, tag):
        if tag == "h2" and self.in_h2:
            self.in_h2 = False
        if tag == "article" and self.in_article:
            self.in_article = False
            if self.current_title and self.current_url:
                self.movies.append((self.current_title, self.current_url, self.current_image))
            self.current_title = ""
            self.current_url = ""
            self.current_image = ""


def build_search_url(query):
    """Build the paginated search URL for a given query string."""
    encoded = query.replace(" ", "%20")
    return f"{BASE_URL}/search/title/{encoded}/"


def fetch_page(url):
    """Fetch raw HTML from a URL."""
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req) as response:
        return response.read().decode("utf-8", errors="ignore")


def parse_movies(html):
    """Parse movies from an HTML page. Returns (list of movie tuples, total_pages)."""
    parser = MovieParser()
    parser.feed(html)
    return parser.movies, parser.total_pages


def is_series_episode(title):
    """Return True if the title looks like a series episode (e.g. S01E05)."""
    return bool(re.search(r's\d+e\d+', title, re.IGNORECASE))


def filter_movies(movies):
    """Filter out series episodes, returning only movies."""
    return [(title, url, image) for title, url, image in movies if not is_series_episode(title)]


def format_movie_url(url):
    """Ensure the movie URL is absolute."""
    if url.startswith("//"):
        return f"https:{url}"
    if url.startswith("/"):
        return f"{BASE_URL}{url}"
    return url


def search_movies(query, verbose=True):
    """
    Search for movies by query string, across all paginated results.
    Excludes series episodes.

    Returns a list of dicts: [{title, url, image}, ...]

    Usage:
        movies = search_movies("star wars")
        movies = search_movies("matrix", verbose=False)
    """
    search_url = build_search_url(query)
    results = []

    if verbose:
        print(f"Fetching page 1 for '{query}'...")
    html = fetch_page(search_url + "1")
    movies, total_pages = parse_movies(html)
    results.extend(filter_movies(movies))

    if verbose:
        print(f"Total pages found: {total_pages}")

    for page in range(2, total_pages + 1):
        if verbose:
            print(f"Fetching page {page}...")
        html = fetch_page(search_url + str(page))
        movies, _ = parse_movies(html)
        results.extend(filter_movies(movies))

    return [
        {
            "title": title,
            "url": format_movie_url(url),
            "image": image,
        }
        for title, url, image in results
    ]


def print_movies(movies):
    """Pretty-print a list of movie dicts."""
    print(f"\n{'='*60}")
    print(f"Found {len(movies)} movies:")
    print(f"{'='*60}")
    for i, movie in enumerate(movies, 1):
        print(f"{i:3}. {movie['title']}")
        print(f"     URL:   {movie['url']}")
        print(f"     Image: {movie['image']}")
        print()


# --- Example usage ---
#if __name__ == "__main__":
   # movies = search_movies("star wars")
  #  print_movies(movies)

    # Other ways to use the functions:
    #
    # Just get the data silently:
    # movies = search_movies("matrix", verbose=False)
    #
    # Access individual fields:
    # for movie in movies:
    #     print(movie["title"])
    #     print(movie["url"])
    #     print(movie["image"])
    #
    # Check if something is a series episode:
    # print(is_series_episode("Star Wars: Andor S02E01"))  # True
    # print(is_series_episode("Rogue One"))                 # False



def list_movie_providers( movie_url, title):
    xbmc.log(f"Playing: {title}")
    parsed = urlparse(movie_url)
    referer = f"{parsed.scheme}://{parsed.netloc}"
    xbmcgui.Dialog().notification("Loading", f"Extracting video for {title}","", 3000)

    m3u8_url = get_all_video_urls(movie_url,referer)
    """if not m3u8_url:
        xbmcgui.Dialog().notification("Error", "Failed to extract video URL", xbmcgui.NOTIFICATION_ERROR)
        return """
    if( m3u8_url != "None"):
        play_url = build_kodi_play_url(m3u8_url, referer)
        li = xbmcgui.ListItem(path=play_url)
        li.setProperty("IsPlayable", "true")
        li.setProperty("inputstream", "inputstream.adaptive")
        log(int(sys.argv[1]))

        xbmcplugin.setResolvedUrl(int(sys.argv[1]), succeeded=True, listitem=li)


def get_stream_from_server(url):
    """Ask local server to extract m3u8 URL from hoster page."""
    try:
        r = requests.get(f"{SERVER}/get_m3u8_movie", params={"url": url}, timeout=6000)
        r.raise_for_status()
        data = r.json()
        log(f"SERVER RESPONSE | Movie URL: {data}")
        return data.get("urls")
    except requests.RequestException as e:
        log(f"Server request failed: {e}")
        return None
    

def get_stream_from_server2(url):
    """Ask local server to extract m3u8 URL from hoster page."""
    try:
        r = requests.get(f"{SERVER}/get_m3u8_movie_veev", params={"url": url}, timeout=6000)
        r.raise_for_status()
        data = r.json()
        log(f"SERVER RESPONSE | Movie URL: {data}")
        return data.get("urls")
    except requests.RequestException as e:
        log(f"Server request failed: {e}")
        return None



def get_all_video_urls(episode_url, referer):
    """Show provider list first, then resolve only selected one"""

    log(f"Extracting providers from {episode_url}")

    try:
        r = requests.get(episode_url, headers=HEADERS, timeout=15)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")

        stream_list = soup.select("#grap-stream-list ul.currentStreamLinks")
        if not stream_list:
            return None

        provider_buttons = []

        for ul in stream_list:
            # Provider name from <p class="hostName">
            name_tag = ul.select_one("p.hostName")
            if not name_tag:
                continue
            provider_name = name_tag.get_text(strip=True)

            # Play URL: prefer data-player-url, fall back to href
            play_tag = ul.select_one("li.streamPlayBtn a.button")
            if not play_tag:
                continue

            play_url = play_tag.get("data-player-url") or play_tag.get("href")
            if not play_url or play_url == "#":
                continue

            if play_url.startswith("/"):
                play_url = referer + play_url

            provider_buttons.append({
                "label": provider_name,
                "play_url": play_url
            })

        if not provider_buttons:
            return None

        # Show dialog FIRST
        labels = [p["label"] for p in provider_buttons]
        selected_index = xbmcgui.Dialog().select("Choose Provider", labels)

        if selected_index == -1:
            return None

        selected = provider_buttons[selected_index]
        log(selected)

        # Only now call server for chosen provider
        #if selected.get('label') == 'Veev HD':
            #url = get_stream_from_server2(selected["play_url"])

        play_url=resolveUrl(selected["play_url"])
        #play_url="http://127.0.0.1:8001/proxy/51fd956d-e352-498e-80ba-fbc37a5e0f95"
        #play_url="http://127.0.0.1:8001/proxy/d71e33f9-f1b4-4651-b5e9-bc0d562c3f8a"
        li = xbmcgui.ListItem(path=play_url)
        li.setInfo('video', {'title': 'Film'})
        li.setProperty("IsPlayable", "true")
            # Do NOT set inputstream addon for MP4
        xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)
        stream_url="None"
        log("DONE!")
        #else:
         #   stream_url = get_stream_from_server(selected["play_url"])

        return stream_url

    except Exception as e:
        log(f"Error extracting video: {e}")
        return None
    
from urllib.parse import quote

def build_kodi_play_url(m3u8_url, referer, cookies=None):
    log("Start PLAYBACK")


    headers = {
        "User-Agent": HEADERS["User-Agent"],
        "Referer": referer
    }

    log(headers)
    log(referer)

    if cookies:
        headers["Cookie"] = cookies

    # Properly URL encode header values
    header_string = "&".join(
        f"{k}={quote(v)}" for k, v in headers.items()
    )

    return f"{m3u8_url}|{header_string}"


def resolveUrl(media_url, validate_only=False):
    # Resolve media URL using available resolver
    try:
        try:
            import resolveurl as resolver
        except ImportError:
            import urlresolver as resolver
        
        if media_url:
            if validate_only:
                return resolver.HostedMediaFile(media_url).valid_url()
            log(resolver.resolve(media_url))
            return resolver.resolve(media_url)
    except Exception as e:
        if DEBUG:
            print("Resolve error:", e)
    return False