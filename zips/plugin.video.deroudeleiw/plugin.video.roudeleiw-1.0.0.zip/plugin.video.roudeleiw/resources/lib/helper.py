import xbmc
import xbmcgui
import xbmcplugin

def prompt_user_input(label, handle=None):
    """
    Display a Kodi input dialog and return the entered string.
    Ends the directory if no input is given and handle is provided.
    """
    term = xbmcgui.Dialog().input(label)
    if not term and handle is not None:
        xbmcplugin.endOfDirectory(handle)
        xbmc.log(f"[ROUDELEIW] prompt_user_input | No input provided, ending directory", xbmc.LOGINFO)
        return None

    xbmc.log(f"[ROUDELEIW] prompt_user_input | User entered: {term}", xbmc.LOGINFO)
    return term