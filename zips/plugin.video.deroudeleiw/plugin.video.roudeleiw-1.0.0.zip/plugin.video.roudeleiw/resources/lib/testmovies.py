import xbmc
import xbmcplugin
import xbmcgui
from urllib.parse import urlencode, quote_plus
import sys

handle = None
base_url = None


def build_url(params):
    """Build URL with parameters"""
    return base_url + "?" + urlencode(params, quote_via=quote_plus)


def list_movies():
    """List all available movies"""
    movies = [
        {"title": "Sleepers 1996", 
         "url": "https://wwvvv.sdratmue.com/v1/sleepers1996.mp4"}
    ]
    
    for movie in movies:
        li = xbmcgui.ListItem(label=movie['title'])
        li.setInfo('video', {'title': movie['title'], 'mediatype': 'movie'})
        li.setProperty('IsPlayable', 'true')
        
        # Build URL to play_movie action
        url = build_url({
            'action': 'play_movie',
            'movie_url': movie['url'],
            'title': movie['title']
        })
        
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    
    xbmcplugin.endOfDirectory(handle)


def play_movie(movie_url, title, retries=3, delay=2):
    m3u8_url = "https://cdn-zozs0yofvurnsojd.edgeon-bandwidth.com/engine/hls2-c/01/13285/ojibvgmp8b2t_,n,.urlset/master.m3u8?t=ZicYy6cT7Qh80YOW6-U3TKd2-LAlpUJCYiaNNstSFhs&s=1770726189&e=14400&f=71840801&node=emFhWynNOGuv3pisMCjfukJkzsCosm5hJLraAZ+l22o=&i=104.28&sp=2500&asn=13335&q=n&rq=0oHQwmtmPC90HrKaRgaOCJortCQ44Upz4bRdPv9y"

    play_url = build_kodi_play_url(m3u8_url)

    list_item = xbmcgui.ListItem(path=play_url)
    list_item.setProperty("IsPlayable", "true")

    xbmcplugin.setResolvedUrl(
        handle=int(sys.argv[1]),
        succeeded=True,
        listitem=list_item
    )


def build_kodi_play_url(m3u8_url, referer=None, cookies=None):
    """
    Build a Kodi-playable URL with headers appended.

    :param m3u8_url: Final HLS playlist URL (.m3u8)
    :param referer: Referer URL (optional but often required)
    :param cookies: Cookie string (optional)
    :return: Kodi-compatible URL
    """

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0"
        ),
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9",
    }

    if referer:
        headers["Referer"] = referer

    if cookies:
        headers["Cookie"] = cookies

    header_string = "&".join(
        f"{k}={v.replace(' ', '%20')}" for k, v in headers.items()
    )

    return f"{m3u8_url}|{header_string}"