import requests
from bs4 import BeautifulSoup
from urllib.parse import urlencode, quote_plus, urlparse
import xbmc
import xbmcplugin
import xbmcgui
import re
import json
import sys
from handler.requestHandler import cRequestHandler


HEADERS = {"User-Agent": "Mozilla/5.0", "Referer": "https://s.to"} #test out without referer
SERVER = "http://10.20.1.1:8000"


# ---------------------- UTILITIES ----------------------

def log(msg):
    xbmc.log(f"[ROUDELEIW] {msg}", xbmc.LOGINFO)


def build_url(base_url, params):
    """Build URL with query parameters."""
    return base_url + "?" + urlencode(params, quote_via=quote_plus)


# ---------------------- SEASONS & EPISODES ----------------------

def action_get_seasons(series_url):
    r = requests.get(series_url, headers=HEADERS, timeout=15)
    r.raise_for_status()

    soup = BeautifulSoup(r.text, "html.parser")
    season_nav = soup.find("nav", id="season-nav")
    if not season_nav:
        return []

    seasons = []
    for a in season_nav.select("a[data-season-pill]"):
        seasons.append({
            "season_id": a.get("data-season-pill"),
            "label": "Staffel "+a.get_text(strip=True)
        })

    return seasons

def action_get_episodes(series_url, season_id):
    """
    Fetch episodes from the new HTML structure:
    <section class="episode-section mt-4"> -> <tr class="episode-row">
    """
    season_url = f"{series_url}/staffel-{season_id}"

    r = requests.get(season_url, headers=HEADERS, timeout=15)
    r.raise_for_status()

    soup = BeautifulSoup(r.text, "html.parser")
    episode_section = soup.find("section", class_="episode-section")
    episodes = []

    if episode_section:
        for row in episode_section.select("tr.episode-row"):
            # Get episode URL from onclick
            onclick = row.get("onclick", "")
            match = re.search(r"window\.location=['\"](.+?)['\"]", onclick)
            if not match:
                continue
            ep_url = "https://s.to" + match.group(1)

            # Get episode title (German title)
            title_tag = row.select_one("td.episode-title-cell strong.episode-title-ger")
            title = title_tag.get_text(strip=True) if title_tag else "Unknown"

            episodes.append({
                "title": title,
                "url": ep_url
            })

    return episodes



def action_list_seasons(handle, base_url, series_url, series_title):
    seasons = action_get_seasons(series_url)

    if not seasons:
        xbmcgui.Dialog().notification("No seasons", series_title)
        xbmcplugin.endOfDirectory(handle)
        return

    for season in seasons:
        label = season["label"]

        li = xbmcgui.ListItem(label=label)
        li.setInfo(type="Video", infoLabels={
            "title": label,
            "mediatype": "season"
        })
        li.setProperty('IsPlayable', 'false')

        url = build_url(base_url, {
            'action': 'list_episodes',
            'series_url': series_url,
            'season_id': season['season_id'],
            'title': series_title
        })

        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


def action_list_episodes(handle, base_url, series_url, season_id, series_title):
    episodes = action_get_episodes(series_url, season_id)

    for ep in episodes:
        # Parse episode number if available in title or URL
        # Here we'll try to extract it from URL as fallback
        ep_number = None
        try:
            # URL format: https://s.to/serie/fallout/staffel-1/episode-1
            ep_number = int(ep["url"].rstrip("/").split("-")[-1])
        except Exception:
            ep_number = None

        li = xbmcgui.ListItem(label=ep["title"])

        # Set video info for Kodi + OpenSubtitles
        li.setInfo("video", {
            "title": ep["title"],           # episode title
            "tvshowtitle": series_title,    # series name
            "season": int(season_id),       # season number
            "episode": ep_number or 0,      # episode number
            "mediatype": "episode"
        })

        li.setProperty("IsPlayable", "true")

        play_url = build_url(base_url, {
           "action": "list_providers",
            "episode_url": ep["url"],
            "title": ep["title"]
        })

        xbmc.log(f"[ROUDELEIW] Adding episode: {ep['title']} | episode_url={ep['url']}", xbmc.LOGINFO)
        xbmcplugin.addDirectoryItem(handle, play_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)




# ---------------------- VIDEO EXTRACTION ----------------------
def get_stream_from_server(url):
    """Ask local server to extract m3u8 URL from hoster page."""
    try:
        r = requests.get(f"{SERVER}/get_m3u8", params={"url": url}, timeout=60)
        r.raise_for_status()
        data = r.json()
        log(f"SERVER RESPONSE | Episode URL: {data}")
        return data.get("urls")
    except requests.RequestException as e:
        log(f"Server request failed: {e}")
        return None


def build_kodi_play_url(m3u8_url, referer, cookies=None):
    """Append headers to make HLS stream playable in Kodi."""
    headers = {
        "User-Agent": HEADERS["User-Agent"],
        "Referer": referer
    }
    if cookies:
        headers["Cookie"] = cookies

    header_string = "&".join(f"{k}={v.replace(' ', '%20')}" for k, v in headers.items())
    return f"{m3u8_url}|{header_string}"


def list_providers(handle, episode_url, title):
    xbmc.log(f"Playing: {title}")
    parsed = urlparse(episode_url)
    referer = f"{parsed.scheme}://{parsed.netloc}"
    xbmcgui.Dialog().notification("Loading", f"Extracting video for {title}","", 3000)

    m3u8_url = get_all_video_urls(episode_url,referer)
    """if not m3u8_url:
        xbmcgui.Dialog().notification("Error", "Failed to extract video URL", xbmcgui.NOTIFICATION_ERROR)
        return """
   # log("M3u8 "+m3u8_url)
    #play_url = resolveUrl(m3u8_url)
    #play_url = build_kodi_play_url(m3u8_url, referer)
    log('M3U8:')
    log(m3u8_url)
    media_url=resolveUrl(m3u8_url)
    li = xbmcgui.ListItem(path=media_url)
    
    #li = xbmcgui.ListItem(path=m3u8_url)
    # Inputstream

    xbmcplugin.setResolvedUrl(handle, True, li)

# FIX 1: Remove bandwidth cap - 1500000 is too low and causes quality switches mid-stream
# which causes jumps. Either remove it or raise it significantly:
  #  li.setProperty("inputstream.adaptive.max_bandwidth", "8000000")

# FIX 2: Tell inputstream this is a VOD stream, not live
# This is the most likely cause of your seeking issues
   # li.setProperty("inputstream.adaptive.stream_headers", f"Referer={referer}&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")

# FIX 3: Force inputstream to treat as seekable VOD
    li.setMimeType("application/x-mpegURL")
    li.setContentLookup(False)
    log(int(sys.argv[1]))

    xbmcplugin.setResolvedUrl(int(sys.argv[1]), succeeded=True, listitem=li)



def get_all_video_urls(episode_url, referer):
    """Show provider list first, then resolve only selected one"""

    log(f"Extracting providers from {episode_url}")

    try:
        r = requests.get(episode_url, headers=HEADERS, timeout=15)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")

        buttons = soup.select("#episode-links button.link-box")
        if not buttons:
            return None

        provider_buttons = []

        for button in buttons:
            provider = button.get("data-provider-name")
            play_url = button.get("data-play-url")
            language = button.get("data-language-label")

            if not provider or not play_url:
                continue

            provider_label = f"{provider} {language}"

            if play_url.startswith("/"):
                play_url = referer + play_url

            provider_buttons.append({
                "label": provider_label,
                "play_url": play_url
            })

        if not provider_buttons:
            return None

        # 🔥 Show dialog FIRST
        labels = [p["label"] for p in provider_buttons]
        selected_index = xbmcgui.Dialog().select("Choose Provider", labels)

        if selected_index == -1:
            return None

        selected = provider_buttons[selected_index]

        #sMediaUrl = cVoeResolver().getMediaUrl("https://voe.sx/e/grwectyebfqg")
        log("RESOLVED")
        

        # 🔥 Only now call server for chosen provider
        stream_url=getHosterURL(selected["play_url"])
        #stream_url = get_stream_from_server(selected["play_url"])

        #stream_url = selected["play_url"]
        log("Play URL"+selected["play_url"])
        return stream_url

    except Exception as e:
        log(f"Error extracting video: {e}")
        return None

   
    


def choose_provider(provider_map):
    if not provider_map:
        xbmcgui.Dialog().notification("Error", "No streams found")
        return None

    # Convert dict keys to list
    providers = list(provider_map.keys())

    # Show dialog
    selected_index = xbmcgui.Dialog().select("Choose Provider", providers)

    # If user cancels
    if selected_index == -1:
        return None

    # Get selected provider
    selected_provider = providers[selected_index]

    # Get stream URL from map
    return provider_map[selected_provider]


def resolveUrl(media_url, validate_only=False):
    # Resolve media URL using available resolver
    try:
        try:
            import resolveurl as resolver
        except ImportError:
            import urlresolver as resolver
        
        if media_url:
            if validate_only:
                return resolver.HostedMediaFile(media_url).valid_url()
            log(resolver.resolve(media_url))
            return resolver.resolve(media_url)
    except Exception as e:
        if DEBUG:
            print("Resolve error:", e)



def getHosterURL(hurl):
    Request = cRequestHandler(hurl, caching=False)
    Request.addHeaderEntry('Referer','https://s.to/')
    Request.addHeaderEntry('Upgrade-Insecure-Requests', '1')
    Request.request()
    sUrl = Request.getRealUrl()
    log(sUrl)
    return sUrl
