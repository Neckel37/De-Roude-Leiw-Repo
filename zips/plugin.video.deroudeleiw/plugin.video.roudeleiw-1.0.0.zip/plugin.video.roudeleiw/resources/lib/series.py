import xbmc
import xbmcplugin
import xbmcgui
import requests
from bs4 import BeautifulSoup\

from urllib.parse import quote_plus, urlencode
import series2
from helper import prompt_user_input

handle = None
base_url = None

# --- URL builder ---
def build_url(params):
   return base_url + "?" + urlencode(params, quote_via=quote_plus)

def log(msg):
    xbmc.log(f"[ROUDELEIW] {msg}", xbmc.LOGINFO)   

# --- Router ---
def router(handle, action, args, base_url):
    """
    Main router for all series-related actions
    """
    log(f"action={action} | args={args}")

    # Map actions to functions
    routes = {
        "search_series": prompt_series_search,
        "list_seasons": series2.action_list_seasons,
        "list_episodes": series2.action_list_episodes,
        "list_providers": series2.list_providers
    }

    func = routes.get(action)
    if not func:
        log(f"Unknown action: {action}")
        xbmcplugin.endOfDirectory(handle)
        return

    try:
        if action in ("search_series"):
            term = args.get("term", [""])[0]
            func()  # pass term, handle, base_url

        elif action == "list_seasons":
            series_url = args.get("series_url", [""])[0]
            title = args.get("title", [""])[0]
            if series_url:
                func(handle, base_url, series_url, title)
            else:
                log("list_seasons called without series_url")
                xbmcplugin.endOfDirectory(handle)

        elif action == "list_episodes":
            series_url = args.get("series_url", [""])[0]
            season_id = args.get("season_id", [""])[0]
            title = args.get("title", [""])[0]
            if series_url and season_id:
                func(handle, base_url, series_url, season_id, title)
            else:
                log("list_episodes called without series_url or season_id")
                xbmcplugin.endOfDirectory(handle)

        elif action == "list_providers":
            episode_url = args.get("episode_url", [""])[0]
            title = args.get("title", [""])[0]
            if episode_url:
                func(handle, episode_url, title)        
            else:
                log("play_episode called without episode_url")
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())

    except Exception as e:
        log(f"Exception in action '{action}': {e}")
        import traceback
        log(traceback.format_exc())
        xbmcplugin.endOfDirectory(handle)



# --- UI ---
def prompt_series_search():
    # Get search term from reusable helper
    term = prompt_user_input("Enter series name", handle)
    if not term:
        return

    # Call your existing list_series function
    list_series(term)


def list_series(term):
    if not term:
        xbmcplugin.endOfDirectory(handle)
        return

    xbmc.log(f"[ROUDELEIW] list_series | Searching for: {term}", xbmc.LOGINFO)
    
    url = f"https://s.to/suche?term={quote_plus(term)}"
    headers = {"User-Agent": "Mozilla/5.0"}
    
    # Better error handling
    try:
        r = requests.get(url, headers=headers, timeout=15)
        r.raise_for_status()
    except Exception as e:
        xbmc.log(f"[ROUDELEIW] Failed to fetch search results: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Search Error", f"Could not search for: {term}")
        xbmcplugin.endOfDirectory(handle)
        return
    
    soup = BeautifulSoup(r.text, "html.parser")

    container = soup.select_one("div.row.g-3")
    if not container:
        xbmc.log("[ROUDELEIW] No results container found", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("No Results", f"No series found for: {term}")
        xbmcplugin.endOfDirectory(handle)
        return

    items_found = 0
    seen_urls = set()  # Prevent duplicates
    
    for a in container.select("a[href^='/serie/']"):
        title = a.get_text(strip=True)
        href = a.get("href", "")
        
        # Skip if no title or duplicate URL
        if not title or not href or href in seen_urls:
            continue
            
        seen_urls.add(href)
        full_url = "https://s.to" + href

        # Extract poster from picture tag on search results page
        poster = ""
        picture = a.find("picture")
        if picture:
            # Try to find img inside picture
            img = picture.find("img")
            if img:
                poster = img.get("data-src") or img.get("src") or ""
                xbmc.log(f"[ROUDELEIW] Found poster in picture tag for '{title}': {poster}", xbmc.LOGINFO)
            
            # Or try source tag
            if not poster:
                source = picture.find("source")
                if source:
                    poster = source.get("srcset") or source.get("data-srcset") or ""
                    # srcset might have multiple URLs, take the first
                    if poster:
                        poster = poster.split(",")[0].split()[0]
                        xbmc.log(f"[ROUDELEIW] Found poster in source tag for '{title}': {poster}", xbmc.LOGINFO)
        
        # Make URL absolute
        if poster:
            if poster.startswith("/"):
                poster = "https://s.to" + poster
            elif not poster.startswith("http"):
                poster = "https://s.to/" + poster
        
        # Only fetch description from detail page (poster is already available)
        plot = ""
        if full_url:
            plot = get_series_description(full_url)

        li = xbmcgui.ListItem(title)
        li.setInfo(
            "video",
            {
                "title": title,
                "plot": plot,
                "mediatype": "tvshow"
            }
        )

        if poster:
            xbmc.log(f"[ROUDELEIW] Setting poster for '{title}': {poster}", xbmc.LOGINFO)
            li.setArt({
                "thumb": poster,
                "poster": poster,
                "fanart": poster
            })
        else:
            xbmc.log(f"[ROUDELEIW] No poster found for '{title}'", xbmc.LOGWARNING)

        li.setProperty("IsPlayable", "false")

        item_url = build_url({
            "action": "list_seasons",
            "series_url": full_url,
            "title": title

            
        })

        xbmcplugin.addDirectoryItem(handle, item_url, li, isFolder=True)
        items_found += 1

    xbmc.log(f"[ROUDELEIW] list_series | Found {items_found} results", xbmc.LOGINFO)
    xbmcplugin.endOfDirectory(handle)

def get_series_description(series_url):
    """Fetch description from series detail page"""

    headers = {"User-Agent": "Mozilla/5.0"}
    description = ""

    try:
        r = requests.get(series_url, headers=headers, timeout=15)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")

        # Description
        desc_span = soup.select_one("span.description-text")
        if desc_span:
            description = desc_span.get_text(strip=True)

    except Exception as e:
        xbmc.log(f"[ROUDELEIW] Failed to fetch series description from {series_url}: {e}", xbmc.LOGWARNING)

    return description